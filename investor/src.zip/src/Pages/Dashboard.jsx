import { useContext } from "react";
import { AuthContext } from "../context/AuthContext";
import { useNavigate } from "react-router-dom";

const Dashboard = () => {
  const { user, role, logout } = useContext(AuthContext);
  const navigate = useNavigate();

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-gray-100">
      <h1 className="text-2xl font-bold mb-4">Dashboard</h1>
      <p>Welcome, <span className="font-bold">{user?.email}</span>!</p>
      <p className="text-gray-700 mb-4">Role: <span className="font-semibold">{role}</span></p>

      {role === "Investor" && <p className="text-green-600">You can browse and invest in businesses.</p>}
      {role === "BusinessPerson" && <p className="text-blue-600">You can create and manage business proposals.</p>}

      <button onClick={() => { logout(); navigate("/login"); }} 
        className="mt-4 bg-red-500 text-white px-4 py-2 rounded">
        Logout
      </button>
    </div>
  );
};

export default Dashboard;
