// src/components/Navbar.jsx
import { Link } from "react-router-dom";
import { useContext } from "react";
import { AuthContext } from "../context/AuthContext";
import { useNavigate } from "react-router-dom";

const Navbar = () => {
  const { user, role, logout } = useContext(AuthContext);
  const navigate = useNavigate();

  return (
    <nav className="bg-blue-600 p-4 shadow-md">
      <div className="container mx-auto flex justify-between items-center">
        <Link to="/" className="text-white text-xl font-bold">
          Investor Connect
        </Link>

        <div className="space-x-4">
          {!user ? (
            <>
              <Link to="/login" className="text-white px-3 py-1 rounded hover:bg-blue-700">
                Login
              </Link>
              <Link to="/register" className="text-white px-3 py-1 rounded hover:bg-blue-700">
                Register
              </Link>
            </>
          ) : (
            <>
              <Link to="/dashboard" className="text-white px-3 py-1 rounded hover:bg-blue-700">
                Dashboard
              </Link>
              {role && role === "Investor" && (
                <Link to="/proposals" className="text-white px-3 py-1 rounded hover:bg-blue-700">
                  View Proposals
                </Link>
              )}
              {user && role === "BusinessPerson" && (
                <Link to="/interested-investors" className="text-white px-3 py-1 rounded hover:bg-blue-700">
                    Interested Investors
                </Link>
                )}
            {user && role === "BusinessPerson" && (
            <Link to="/my-proposals" className="text-white px-3 py-1 rounded hover:bg-blue-700">
                My Proposals
            </Link>
            )}

              <button
                onClick={() => {
                  logout();
                  navigate("/login");
                }}
                className="text-white bg-red-500 px-3 py-1 rounded hover:bg-red-600"
              >
                Logout
              </button>
            </>
          )}
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
